# Squint
Blur and desaturate your webpage to see how well the design holds up. A tool for web designers and developers.

This works as a local Chrome extension, but hasn't been published. To test it, follow the instructions [here](https://developer.chrome.com/docs/extensions/mv3/getstarted/development-basics/) to load the unpacked extension files.

![image](https://user-images.githubusercontent.com/304177/213938342-30b53b89-18ae-4736-98c0-5bd120b9d6ee.png)
