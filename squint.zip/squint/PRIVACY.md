# Privacy Policy

As of now, I collect no user data. [The only Chrome extension I've written](https://github.com/method-run/Squint) is an incredibly small, open source, free toy that lets you desaturate and blur your active tab.

It doesn't collect or save any information about you or your browser. I don't want it. I don't want to sell it. I don't want to handle it.

This is a toy, and you're welcome to inspect the source code for yourself, deconstruct it, and build your own.

_Updated 22 Jan 2023_